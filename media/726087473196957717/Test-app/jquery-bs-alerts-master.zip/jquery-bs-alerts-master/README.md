# jQuery Bootstrap Alerts

> A jQuery plugin for displaying Bootstrap alerts via jQuery events.

[![Build Status](https://travis-ci.org/eltimn/jquery-bs-alerts.svg?branch=master)](https://travis-ci.org/eltimn/jquery-bs-alerts)

## Requires
- jQuery
- Bootstrap

[Documentation](https://eltimn.github.com/jquery-bs-alerts)

[Download](https://github.com/eltimn/jquery-bs-alerts/releases)

**License**: MIT [http://www.opensource.org/licenses/mit-license.php](http://www.opensource.org/licenses/mit-license.php)
